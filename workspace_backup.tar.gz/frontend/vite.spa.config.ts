import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";

const jupyterProxyBase =
  "/jupyter-hack-team-1278-260611071930-c4b5f661/proxy/3000/";

export default defineConfig({
  base: jupyterProxyBase,
  plugins: [react(), tailwindcss(), tsconfigPaths()],
  build: {
    outDir: "dist/spa",
    emptyOutDir: true,
  },
});
