import sys, os
sys.path.insert(0, "/workspace/backend")
from fastapi import BackgroundTasks, FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import tempfile, os, time, json, uuid
from ingestion.loader import DocumentLoader
from ingestion.embedder import DocumentEmbedder
from agents.audit_agent import AuditAgent
from models.schemas import AuditRequest, AuditResponse, HealthResponse, IngestionJobResponse, IngestionStatusResponse
from config import settings

app = FastAPI(title="ComplianceIQ API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

loader = DocumentLoader()
embedder = DocumentEmbedder()
agent = AuditAgent()
ingestion_jobs = {}


def _create_job(doc_name: str) -> str:
    job_id = uuid.uuid4().hex
    ingestion_jobs[job_id] = {
        "job_id": job_id,
        "status": "queued",
        "message": "Waiting to process file...",
        "doc_name": doc_name,
        "result": None,
        "error": None,
    }
    return job_id


def _update_job(job_id: str, **updates):
    ingestion_jobs[job_id].update(updates)


def _ingest_document_job(job_id: str, tmp_path: str, filename: str, doc_type: str, start: float):
    try:
        _update_job(job_id, status="processing", message="Parsing document...")
        chunks = loader.load(tmp_path)
        _update_job(job_id, message=f"Embedding {len(chunks)} document chunks...")
        cid = embedder.embed_and_store(chunks, filename, doc_type)
        _update_job(
            job_id,
            status="complete",
            message="Document ready",
            result={
                "collection_id": cid,
                "doc_name": filename,
                "chunk_count": len(chunks),
                "elapsed_seconds": round(time.time() - start, 2),
            },
        )
    except Exception as exc:
        _update_job(job_id, status="failed", message="Document ingestion failed", error=str(exc))
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def _ingest_ruleset_job(job_id: str, tmp_path: str, filename: str, start: float):
    try:
        _update_job(job_id, status="processing", message="Parsing ruleset...")
        with open(tmp_path, "rb") as f:
            ruleset = json.loads(f.read())
        rules = ruleset.get("rules", [])
        _update_job(job_id, message=f"Embedding {len(rules)} rules...")
        cid = embedder.embed_ruleset(ruleset, filename)
        _update_job(
            job_id,
            status="complete",
            message="Ruleset ready",
            result={
                "collection_id": cid,
                "doc_name": filename,
                "rule_count": len(rules),
                "elapsed_seconds": round(time.time() - start, 2),
            },
        )
    except Exception as exc:
        _update_job(job_id, status="failed", message="Ruleset ingestion failed", error=str(exc))
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(status="ok", llm_endpoint=settings.LLM_BASE_URL, collections=embedder.list_collections())

@app.post("/ingest/document", response_model=IngestionJobResponse)
async def ingest_document(background_tasks: BackgroundTasks, file: UploadFile = File(...), doc_type: str = "document"):
    if not file.filename.endswith((".pdf", ".docx", ".txt")):
        raise HTTPException(400, "Supported: PDF, DOCX, TXT")
    start = time.time()
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name
    job_id = _create_job(file.filename)
    background_tasks.add_task(_ingest_document_job, job_id, tmp_path, file.filename, doc_type, start)
    return IngestionJobResponse(job_id=job_id, status="queued", doc_name=file.filename)

@app.post("/ingest/ruleset", response_model=IngestionJobResponse)
async def ingest_ruleset(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    if not file.filename.endswith(".json"):
        raise HTTPException(400, "Ruleset must be JSON")
    start = time.time()
    with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name
    job_id = _create_job(file.filename)
    background_tasks.add_task(_ingest_ruleset_job, job_id, tmp_path, file.filename, start)
    return IngestionJobResponse(job_id=job_id, status="queued", doc_name=file.filename)

@app.get("/ingest/{job_id}", response_model=IngestionStatusResponse)
async def get_ingestion_status(job_id: str):
    job = ingestion_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Ingestion job not found")
    return IngestionStatusResponse(**job)

@app.post("/audit", response_model=AuditResponse)
async def run_audit(request: AuditRequest):
    start = time.time()
    result = await agent.run(request.document_collection_id, request.ruleset_collection_id, request.doc_name, request.ruleset_name)
    result.elapsed_seconds = round(time.time()-start, 2)
    return result

@app.get("/collections")
async def list_collections():
    return {"collections": embedder.list_collections()}

@app.delete("/collections/{collection_id}")
async def delete_collection(collection_id: str):
    embedder.delete_collection(collection_id)
    return {"deleted": collection_id}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
