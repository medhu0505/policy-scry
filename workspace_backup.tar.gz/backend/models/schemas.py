from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from enum import Enum

class RiskLevel(str, Enum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    PASS = "PASS"

class Violation(BaseModel):
    rule_id: str
    rule_description: str
    document_excerpt: str
    document_location: str
    policy_reference: str
    conflict_explanation: str
    risk_level: RiskLevel
    confidence_score: float = Field(ge=0.0, le=1.0)
    suggested_action: str

class AuditSummary(BaseModel):
    total_rules_checked: int
    violations_high: int
    violations_medium: int
    violations_low: int
    rules_passed: int
    overall_compliance_score: float
    overall_risk: RiskLevel

class AuditResponse(BaseModel):
    doc_name: str
    ruleset_name: str
    summary: AuditSummary
    violations: List[Violation]
    agent_reasoning_steps: List[str]
    elapsed_seconds: Optional[float] = None
    model_used: Optional[str] = None

class AuditRequest(BaseModel):
    document_collection_id: str
    ruleset_collection_id: str
    doc_name: str
    ruleset_name: str

class IngestionResponse(BaseModel):
    collection_id: str
    doc_name: str
    chunk_count: int
    elapsed_seconds: float

class IngestionJobResponse(BaseModel):
    job_id: str
    status: str
    doc_name: str

class IngestionStatusResponse(BaseModel):
    job_id: str
    status: str
    message: str
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

class HealthResponse(BaseModel):
    status: str
    llm_endpoint: str
    collections: List[str]
