import sys; sys.path.insert(0, "/workspace/backend")
from typing import List, Dict
import json, asyncio
from functools import partial
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from ingestion.embedder import DocumentEmbedder
from models.schemas import AuditResponse, AuditSummary, Violation, RiskLevel
from config import settings

SYSTEM_PROMPT = """You are a senior compliance auditor AI. Validate documents against compliance rules and produce structured audit findings. Output ONLY valid JSON. No preamble."""

RULE_PROMPT = """Audit this document against the compliance rule below.

RULE ID: {rule_id}
RULE DESCRIPTION: {rule_description}
REQUIREMENT: {rule_requirement}
EXPECTED RISK IF VIOLATED: {risk_level}

RELEVANT DOCUMENT SECTIONS:
{document_sections}

Respond with ONLY this JSON:
{{
  "rule_id": "{rule_id}",
  "rule_description": "{rule_description}",
  "document_excerpt": "<exact quote max 200 chars>",
  "document_location": "<page/chunk reference>",
  "policy_reference": "<rule id and key phrase>",
  "conflict_explanation": "<clear explanation>",
  "risk_level": "<HIGH|MEDIUM|LOW|PASS>",
  "confidence_score": <0.0-1.0>,
  "suggested_action": "<specific action or No action required>"
}}"""

class AuditAgent:
    def __init__(self):
        self.embedder = DocumentEmbedder()
        self.llm = ChatOpenAI(
            base_url=settings.LLM_BASE_URL,
            api_key="not-required",
            model=settings.LLM_MODEL,
            temperature=settings.LLM_TEMPERATURE,
            max_tokens=settings.LLM_MAX_TOKENS,
            timeout=settings.LLM_TIMEOUT,
        )

    async def run(self, document_collection_id: str, ruleset_collection_id: str, doc_name: str, ruleset_name: str) -> AuditResponse:
        rules = self.embedder.get_all_rules(ruleset_collection_id)
        violations, reasoning = [], []
        reasoning.append(f"Loaded {len(rules)} rules from {ruleset_name}")
        for i in range(0, len(rules), 3):
            batch = rules[i:i+3]
            tasks = [self._check_rule(r, document_collection_id, reasoning) for r in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for r in results:
                if isinstance(r, Exception):
                    reasoning.append(f"Rule check error: {r}")
                elif r:
                    violations.append(r)
        summary = self._summarize(violations, len(rules))
        reasoning.append(f"Done. Score: {summary.overall_compliance_score}% | HIGH:{summary.violations_high} MED:{summary.violations_medium} LOW:{summary.violations_low}")
        return AuditResponse(doc_name=doc_name, ruleset_name=ruleset_name, summary=summary, violations=violations, agent_reasoning_steps=reasoning, model_used=settings.LLM_MODEL)

    async def _check_rule(self, rule: Dict, doc_collection_id: str, reasoning: List[str]):
        meta = rule["metadata"]
        rule_id = meta["rule_id"]
        retrieved = self.embedder.retrieve(doc_collection_id, f"{meta['description']} {meta['requirement']}")
        if not retrieved:
            reasoning.append(f"[{rule_id}] No content found — HIGH gap")
            return Violation(rule_id=rule_id, rule_description=meta["description"], document_excerpt="[No content found]", document_location="N/A", policy_reference=f"{rule_id}", conflict_explanation="Document has no content addressing this requirement.", risk_level=RiskLevel.HIGH, confidence_score=0.95, suggested_action=f"Add section: {meta['requirement']}")
        sections = "\n\n".join([f"[Chunk {r['metadata'].get('chunk_index','?')} | Similarity: {r['similarity']}]\n{r['text']}" for r in retrieved])
        prompt = RULE_PROMPT.format(rule_id=rule_id, rule_description=meta["description"], rule_requirement=meta["requirement"], risk_level=meta.get("risk_level","MEDIUM"), document_sections=sections)
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(None, partial(self.llm.invoke, [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=prompt)]))
        raw = response.content.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"): raw = raw[4:]
        try:
            data = json.loads(raw.strip())
            v = Violation(**data)
            reasoning.append(f"[{rule_id}] {v.risk_level} | conf:{v.confidence_score:.2f}")
            return v
        except Exception as e:
            reasoning.append(f"[{rule_id}] Parse error: {e}")
            return None

    def _summarize(self, violations: List[Violation], total: int) -> AuditSummary:
        high = sum(1 for v in violations if v.risk_level == RiskLevel.HIGH)
        med = sum(1 for v in violations if v.risk_level == RiskLevel.MEDIUM)
        low = sum(1 for v in violations if v.risk_level == RiskLevel.LOW)
        passed = sum(1 for v in violations if v.risk_level == RiskLevel.PASS)
        score = round(((total - high - med - low) / total) * 100, 1) if total else 0.0
        risk = RiskLevel.HIGH if high else RiskLevel.MEDIUM if med else RiskLevel.LOW if low else RiskLevel.PASS
        return AuditSummary(total_rules_checked=total, violations_high=high, violations_medium=med, violations_low=low, rules_passed=passed, overall_compliance_score=score, overall_risk=risk)
