import sys; sys.path.insert(0, "/workspace/backend")
from typing import List
from pathlib import Path
import re
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader, TextLoader
from langchain_core.documents import Document
from config import settings

class DocumentLoader:
    def __init__(self):
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.CHUNK_SIZE,
            chunk_overlap=settings.CHUNK_OVERLAP,
            separators=["\n\n", "\n", ".", ";", ",", " "],
        )

    def load(self, file_path: str) -> List[Document]:
        path = Path(file_path)
        suffix = path.suffix.lower()
        if suffix == ".pdf":
            raw_docs = PyPDFLoader(file_path).load()
        elif suffix == ".docx":
            raw_docs = Docx2txtLoader(file_path).load()
        elif suffix == ".txt":
            raw_docs = TextLoader(file_path, encoding="utf-8").load()
        else:
            raise ValueError(f"Unsupported: {suffix}")
        for doc in raw_docs:
            doc.page_content = re.sub(r'\s+', ' ', doc.page_content).strip()
        chunks = self.splitter.split_documents(raw_docs)
        for i, chunk in enumerate(chunks):
            chunk.metadata["chunk_index"] = i
        return [c for c in chunks if len(c.page_content.strip()) > 30]
