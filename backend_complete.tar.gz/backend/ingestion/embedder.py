import sys; sys.path.insert(0, "/workspace/backend")
from typing import List, Dict
import chromadb
from chromadb.config import Settings as ChromaSettings
import hashlib, time
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings
from config import settings

class DocumentEmbedder:
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=settings.CHROMA_PERSIST_DIR,
            settings=ChromaSettings(anonymized_telemetry=False)
        )
        self.embedding_fn = HuggingFaceEmbeddings(
            model_name=settings.EMBEDDING_MODEL,
            model_kwargs={"device": settings.EMBEDDING_DEVICE},
            encode_kwargs={"normalize_embeddings": True}
        )

    def _make_id(self, name: str) -> str:
        return hashlib.md5(f"{name}_{int(time.time())}".encode()).hexdigest()[:16]

    def embed_and_store(self, chunks: List[Document], doc_name: str, doc_type: str = "document") -> str:
        cid = self._make_id(doc_name)
        col = self.client.get_or_create_collection(name=cid, metadata={"doc_name": doc_name, "hnsw:space": "cosine"})
        texts = [c.page_content for c in chunks]
        embeddings = self.embedding_fn.embed_documents(texts)
        metadatas = [{"doc_name": doc_name, "doc_type": doc_type, "chunk_index": c.metadata.get("chunk_index", i), "page": c.metadata.get("page", 0)} for i, c in enumerate(chunks)]
        ids = [f"{cid}_{i}" for i in range(len(chunks))]
        col.upsert(ids=ids, embeddings=embeddings, documents=texts, metadatas=metadatas)
        return cid

    def embed_ruleset(self, ruleset: Dict, ruleset_name: str) -> str:
        rules = ruleset.get("rules", [])
        cid = self._make_id(ruleset_name)
        col = self.client.get_or_create_collection(name=cid, metadata={"doc_name": ruleset_name, "doc_type": "ruleset", "hnsw:space": "cosine"})
        texts = [f"{r['id']}: {r['description']}. Requirement: {r['requirement']}" for r in rules]
        embeddings = self.embedding_fn.embed_documents(texts)
        metadatas = [{"rule_id": r["id"], "description": r["description"], "requirement": r["requirement"], "risk_level": r.get("risk", "MEDIUM")} for r in rules]
        ids = [f"{cid}_{r['id']}" for r in rules]
        col.upsert(ids=ids, embeddings=embeddings, documents=texts, metadatas=metadatas)
        return cid

    def retrieve(self, collection_id: str, query: str, top_k: int = None) -> List[Dict]:
        top_k = top_k or settings.RETRIEVAL_TOP_K
        col = self.client.get_collection(collection_id)
        qe = self.embedding_fn.embed_query(query)
        results = col.query(query_embeddings=[qe], n_results=min(top_k, col.count()), include=["documents", "metadatas", "distances"])
        return [{"text": d, "metadata": m, "similarity": round(1-dist, 4)} for d, m, dist in zip(results["documents"][0], results["metadatas"][0], results["distances"][0])]

    def get_all_rules(self, collection_id: str) -> List[Dict]:
        col = self.client.get_collection(collection_id)
        results = col.get(include=["documents", "metadatas"])
        return [{"text": d, "metadata": m} for d, m in zip(results["documents"], results["metadatas"])]

    def list_collections(self) -> List[str]:
        return [c.name for c in self.client.list_collections()]

    def delete_collection(self, collection_id: str):
        self.client.delete_collection(collection_id)
