import sys, os
sys.path.insert(0, "/workspace/backend")
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import tempfile, os, time, json
from ingestion.loader import DocumentLoader
from ingestion.embedder import DocumentEmbedder
from agents.audit_agent import AuditAgent
from models.schemas import AuditRequest, AuditResponse, IngestionResponse, HealthResponse
from config import settings

app = FastAPI(title="ComplianceIQ API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

loader = DocumentLoader()
embedder = DocumentEmbedder()
agent = AuditAgent()

@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(status="ok", llm_endpoint=settings.LLM_BASE_URL, collections=embedder.list_collections())

@app.post("/ingest/document", response_model=IngestionResponse)
async def ingest_document(file: UploadFile = File(...), doc_type: str = "document"):
    if not file.filename.endswith((".pdf", ".docx", ".txt")):
        raise HTTPException(400, "Supported: PDF, DOCX, TXT")
    start = time.time()
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name
    try:
        chunks = loader.load(tmp_path)
        cid = embedder.embed_and_store(chunks, file.filename, doc_type)
        return IngestionResponse(collection_id=cid, doc_name=file.filename, chunk_count=len(chunks), elapsed_seconds=round(time.time()-start, 2))
    finally:
        os.unlink(tmp_path)

@app.post("/ingest/ruleset")
async def ingest_ruleset(file: UploadFile = File(...)):
    if not file.filename.endswith(".json"):
        raise HTTPException(400, "Ruleset must be JSON")
    content = await file.read()
    ruleset = json.loads(content)
    cid = embedder.embed_ruleset(ruleset, file.filename)
    return {"collection_id": cid, "rule_count": len(ruleset.get("rules", []))}

@app.post("/audit", response_model=AuditResponse)
async def run_audit(request: AuditRequest):
    start = time.time()
    result = await agent.run(request.document_collection_id, request.ruleset_collection_id, request.doc_name, request.ruleset_name)
    result.elapsed_seconds = round(time.time()-start, 2)
    return result

@app.get("/collections")
async def list_collections():
    return {"collections": embedder.list_collections()}

@app.delete("/collections/{collection_id}")
async def delete_collection(collection_id: str):
    embedder.delete_collection(collection_id)
    return {"deleted": collection_id}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
